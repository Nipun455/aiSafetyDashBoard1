import React from 'react';
import IncidentDashboard from './Components/IncidentDashboard';
import './index.css';

function App() {
  return <IncidentDashboard />;
}

export default App;
